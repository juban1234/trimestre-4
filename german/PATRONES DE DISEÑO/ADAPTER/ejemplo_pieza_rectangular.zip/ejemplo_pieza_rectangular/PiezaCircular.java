class PiezaCircular {
    private double radio;

    public PiezaCircular(double radio) {
        this.radio = radio;
    }

    public double getRadio() {
        return radio;
    }
}
