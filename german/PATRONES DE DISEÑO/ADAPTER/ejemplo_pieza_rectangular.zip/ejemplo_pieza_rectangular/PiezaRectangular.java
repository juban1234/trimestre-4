class PiezaRectangular {
    private double ancho;
    private double alto;

    public PiezaRectangular(double ancho, double alto) {
        this.ancho = ancho;
        this.alto = alto;
    }

    public double getAncho() {
        return ancho;
    }

    public double getAlto() {
        return alto;
    }
}
