
interface Car {
    double cost();
    String getDescription();
}
