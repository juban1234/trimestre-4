package modelo.operaciones;

import java.awt.Color;
import java.util.ArrayList;

import modelo.vo.EstudianteVO;

public class Procesos {


	
	public double calcularPromedio(double n1,double n2,double n3) {
		
		
		
		return 0;
		
	}

	public String calcularDefinitiva(double promedio) {

		
		return "";
	}

	public double calcularPromedio(EstudianteVO est) {

	
		return 0;
	}

	public void registrarEnBD(EstudianteVO estudiante) {
	
	}

	public void imprimirListaEstudiantes() {

	}
	
	public ArrayList<EstudianteVO> getListaPersonas(){
		return null;
	}

	public EstudianteVO obtenerEstudiante(String doc) {
		EstudianteVO p=null;

		return p;
		
	}
	
}
