package modelo.vo;

public class ModeloDatos {

}
