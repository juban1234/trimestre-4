package controlador;

import vista.gui.VentanaOperaciones;

public class Principal {

	public static void main(String[] args) {
		new VentanaOperaciones().setVisible(true);;
	}

	

}
